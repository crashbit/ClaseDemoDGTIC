//
//  VideoViewController.swift
//  ClaseDemo
//
//  Created by Germán Santos Jaimes on 18/10/24.
//

import UIKit
import AVKit
import AVFoundation
import MobileCoreServices

class VideoViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    @IBOutlet weak var addVideo: UIButton!
    var videoController = UIImagePickerController()
    var videoPlayer: AVPlayerViewController?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // Video desde el bundle
    @IBAction func playVideoBundleButton(_ sender: UIButton){

        if let videoURL = Bundle.main.url(forResource: "prueba", withExtension: "mp4") {
            let player = AVPlayer(url: videoURL)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
    
            present(playerViewController, animated: true) {
                player.play()
            }
        }
    }
    
    // Desde la biblioteca del iPhone
    
    @IBAction func viewLibraryButtonAction(_ sender: UIButton) {
      
        // Usando el Picker genérico
        videoController.sourceType = UIImagePickerController.SourceType.photoLibrary
        videoController.mediaTypes = [kUTTypeMovie as String]
        videoController.delegate = self
        
        present(videoController, animated: true, completion: nil)
    }
    
    
    
    public func imageFromVideo(url: URL, at time: TimeInterval, completion: @escaping (UIImage?) -> Void) {
        DispatchQueue.global(qos: .background).async {
            let asset = AVURLAsset(url: url)
            let assetIG = AVAssetImageGenerator(asset: asset)
            assetIG.appliesPreferredTrackTransform = true
            assetIG.apertureMode = AVAssetImageGenerator.ApertureMode.encodedPixels
            let cmTime = CMTime(seconds: time, preferredTimescale: 60)
            let thumbnailImageRef: CGImage
            do {
            thumbnailImageRef = try assetIG.copyCGImage(at: cmTime, actualTime: nil)
            } catch let error {
            print("Error: \(error)")
            return completion(nil)
            }
            DispatchQueue.main.async {
                completion(UIImage(cgImage: thumbnailImageRef))
            }
        }
    }
    
    
    
//        imageFromVideo(url: url!, at: 0) { image in
//        self.addVideo.setImage(image , for: .normal)
//        }

}
