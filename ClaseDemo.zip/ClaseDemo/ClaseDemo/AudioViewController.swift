//
//  AudioViewController.swift
//  ClaseDemo
//
//  Created by Germán Santos Jaimes on 18/10/24.
//

import UIKit
import AVFoundation

class AudioViewController: UIViewController {
    let resultado = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 200))
    var myAudio: AVAudioPlayer?
    private var player : AVPlayer? = nil
    private var playerLayer : AVPlayerLayer? = nil
    @IBOutlet var pausePlayButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultado.alpha = 0
        pausePlayButton.alpha = 0
        // Do any additional setup after loading the view.
    }
    
    @IBAction func playMyAudio(_ sender: UIButton){
        let path = Bundle.main.path(forResource: "prueba.mp3", ofType:nil)!
        let url = URL(fileURLWithPath: path)

        do {
            myAudio = try AVAudioPlayer(contentsOf: url)
            myAudio?.play()
            print("Tocando audio")
            resultado.alpha = 1
            pausePlayButton.alpha = 1
            resultado.center = view.center
            resultado.textAlignment = .center
            resultado.text = "Tocando audio de UNAM-HIMNO"
            view.addSubview(resultado)
        } catch {
            print("No se pudo cargar el audio")
            resultado.alpha = 1
            resultado.center = view.center
            resultado.textAlignment = .center
            resultado.text = "Error al cargar el audio"
            view.addSubview(resultado)
        }
    }
    
    @IBAction func stopMyAudio(_ sender: UIButton){
        if myAudio?.isPlaying == true{
            print("a para el audio")
            myAudio?.pause()
            pausePlayButton.imageView?.image = UIImage(systemName:"pause.circle ")
            
        }else{
            print("a continuar con el audio")
            pausePlayButton.imageView?.image = UIImage(systemName: "play.circle")
            myAudio?.play()
        }
    }
    
    

}
