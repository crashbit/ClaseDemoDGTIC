//
//  Tools.swift
//  ClaseDemo
//
//  Created by Germán Santos Jaimes on 18/10/24.
//

import Foundation
import Photos

final class Tools{
    static let shared = Tools()
    
    init(){}
    
    func checkPermissions(){
        if PHPhotoLibrary.authorizationStatus() != PHAuthorizationStatus.authorized{
            PHPhotoLibrary.requestAuthorization({(status: PHAuthorizationStatus) -> Void in()
            })
        }
        
        if PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.authorized{
        } else {
            PHPhotoLibrary.requestAuthorization(requestAuthorizationHandler)
        }
    }
    
    func requestAuthorizationHandler(status: PHAuthorizationStatus){
        if PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.authorized{
            print("Acceso autorizado a la biblioteca de fotos")
        } else {
            print("No hay acceso a la biblioteca de fotos")
        }
    }
}
